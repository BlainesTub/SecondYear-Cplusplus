#include <string>
#include <fstream>
#include <iostream>
#include <iomanip> 

#include "recover-photos.hpp"

// use this function to convert the length of the record (2 bytes!)
int big_endian_2_bytes_to_int(const std::string &value);


// this is the function that you should implement
int Recover_Photos(std::string filename, bool recover)
{
    int count = 0;


    return count;
}
    
