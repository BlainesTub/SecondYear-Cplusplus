#ifndef __RECOVER_PHOTOS_HPP

int Recover_Photos(std::string filename, bool recover);

#endif
