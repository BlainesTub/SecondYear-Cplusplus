/* expression_tree.cpp
   CSC 116 - Fall 2017
   
*/

#include <string>
#include <cmath> //For exp(), log(), sin(), cos() and pow()
#include "expression_tree.hpp"

/* Constant */
double TreeNodeConstant::evaluate( double x ){
    // we do not use the x, so we ignore it
    // this stops the compiler from issuing a parameter non-used warning/error
    std::ignore = x;


}
TreeNodePtr TreeNodeConstant::differentiate( ){
	//Derivative of a constant is 0

}
TreeNodePtr TreeNodeConstant::duplicate( ){

}

/* Literal X */
double TreeNodeX::evaluate( double x ){

}
TreeNodePtr TreeNodeX::differentiate( ){
	//Derivative of x is 1

}
TreeNodePtr TreeNodeX::duplicate( ){

}

/* Plus operator */
double TreeNodePlus::evaluate( double x ){

}
TreeNodePtr TreeNodePlus::differentiate( ){
	//Derivative of a + b is the sum of the derivatives of each.

}
TreeNodePtr TreeNodePlus::duplicate( ){

}

/* Minus operator */
double TreeNodeMinus::evaluate( double x ){

}
TreeNodePtr TreeNodeMinus::differentiate( ){
	//Derivative of a - b is the difference of the derivatives of each.

}
TreeNodePtr TreeNodeMinus::duplicate( ){

}

/* Multiplication operator */
double TreeNodeMultiply::evaluate( double x ){

}
TreeNodePtr TreeNodeMultiply::differentiate( ){
	//d/dx ( a*b ) = (d/dx a)*b +  a*(d/dx b)

}
TreeNodePtr TreeNodeMultiply::duplicate( ){

}

/* Division operator */
double TreeNodeDivide::evaluate( double x ){

}
TreeNodePtr TreeNodeDivide::differentiate( ){
	//d/dx ( a/b ) = ((d/dx a)*b - a*(d/dx b))/b^2

}
TreeNodePtr TreeNodeDivide::duplicate( ){

}

/* Constant power operator (the exponent will always be a fixed value) */
double TreeNodeConstantPower::evaluate( double x ){

}
TreeNodePtr TreeNodeConstantPower::differentiate( ){
	//d/dx ( a^c ) = c*(d/dx a)*(a)^(c-1)

}
TreeNodePtr TreeNodeConstantPower::duplicate( ){

}

/* exp function */
double TreeNodeExpFunction::evaluate( double x ){

}
TreeNodePtr TreeNodeExpFunction::differentiate( ){
	//d/dx ( e^f(x) ) = (e^f(x))*f'(x)

}
TreeNodePtr TreeNodeExpFunction::duplicate( ){

}

/* log function */
double TreeNodeLogFunction::evaluate( double x ){

}
TreeNodePtr TreeNodeLogFunction::differentiate( ){
	//d/dx ( log( f(x) ) ) = (1/f(x))*f'(x) = f'(x)/f(x)

}
TreeNodePtr TreeNodeLogFunction::duplicate( ){

}

/* sin function */
double TreeNodeSinFunction::evaluate( double x ){

}
TreeNodePtr TreeNodeSinFunction::differentiate( ){
	//d/dx ( sin(f(x)) ) = cos(f(x))*f'(x)

}
TreeNodePtr TreeNodeSinFunction::duplicate( ){

}

/* cos function */
double TreeNodeCosFunction::evaluate( double x ){

}
TreeNodePtr TreeNodeCosFunction::differentiate( ){
	//d/dx ( cos(f(x)) ) = -1*sin(f(x))*f'(x)

}
TreeNodePtr TreeNodeCosFunction::duplicate( ){

}




