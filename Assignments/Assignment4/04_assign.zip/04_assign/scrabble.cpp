#include <iostream>
#include <string>
#include <set>
#include <algorithm>
#include <fstream>
#include <cassert>

#include "scrabble.hpp"

// you can add/remove code from this file as long as you do not modify the declaration of each of the 
// 3 functions  below


int Score(const std::string &word)
{
    // your code goes here
    return -1;
}


dict_type Read_Dictionary(const std::string &filename)
{
    dict_type dict;
    // your code goes here
    return dict;
    
}

words_set_type Find_Best_Words(const dict_type &dict, std::string &tiles)
{
    words_set_type bestWords;

    // your code goes here

    return bestWords;

}

