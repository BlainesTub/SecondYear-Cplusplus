#ifndef __GRAPH_HPP__
#define __GRAPH_HPP__

#include <set>
#include <map>
#include <list>
#include <vector>

// definition of the class
class directed_graph {
private:
    // Add any attributes or private methods you need here


public:
    // Add constructors here (as described in the specification)

    // Do not modify the public interface (names and signatures
	// of public methods) or add any new public members.

    // You can write your implementation either inside the class definition
    // or in the space below (similarly to how directed_graph::print is 
    // implemented).

    bool is_empty();

    void add_edge(const int from, const int to);
    void add_edge(const int from, const int to, const double weight);

    bool edge_exists(const int from, const int to);
    bool vertex_exists(const int vertex);

    std::set<int> vertices();
    std::set<std::pair<int, int>> edges();

    bool remove_edge(const int from, const int to);
    bool remove_vertex(const int vertex);

    std::set<int> predecessors(int vertex);
    std::set<int> successors(int vertex);

    double weight(const int from, const int to);

    directed_graph transpose();
    directed_graph complement(double defaultValue=0);
    directed_graph subgraph(std::set<int> subgraphVertices);

    bool is_reachable(const int from, const int to);

    void print(std::string title="");
}; // directed_graph


void directed_graph::print(std::string title)
{
    std::set<int> setV {vertices()};
    std::set<std::pair<int,int>> setE {edges()};
    std::cout << "Graph " << title << ". It has " << setV.size() 
              << " vertices and "<< setE.size() << " edges" << std::endl;

    for (int v: setV) {
        std::cout << "Vertex [" ;
        std::cout << v ;
        std::cout << "]"<< std::endl;
     }

    for (auto e: setE) {
        assert(edge_exists(e.first, e.second));
        std::cout << "Edge [" << e.first << "] -> [" << e.second << "] weight [" << weight(e.first, e.second) << "]" << std::endl;
    }
    
} // end of print

// Put your code here if you choose to define each method outside of the class definition

#endif
