#include <iostream>
#include <vector>
#include <limits>
#include <cassert>
#include <cstdlib>
#include <string>
#include "matrix.hpp"

// Compute minimum spanning tree of a graph
//
// Parameters:
//      G: input graph (represented by an adjacency matrix)
//
// Result:
//      a matrix representing the minimum spanning tree of G
//
matrix_type Minimum_Spanning_Tree(const matrix_type & G)
{
	unsigned int number_of_vertices = G.size();
    matrix_type result = Create_Matrix(number_of_vertices);

    return result;
    
}

// Calculate the overall cost of a graph
//
// Parameters:
//      G: input graph (represented by an adjacency matrix)
//
// Result:
//      the total sum of the costs of the edges in the graph
//
double Calculate_Cost(const matrix_type &G)
{
    double result {INFINITY};

    return result;
}

